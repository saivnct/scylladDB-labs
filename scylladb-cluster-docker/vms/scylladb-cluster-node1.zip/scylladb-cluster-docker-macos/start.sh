docker compose down

#docker-compose build --no-cache

docker-compose up -d

docker-compose logs -f scylla-node1