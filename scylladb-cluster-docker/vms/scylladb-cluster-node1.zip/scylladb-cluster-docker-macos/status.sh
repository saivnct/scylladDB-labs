docker-compose exec scylla-node1 nodetool status
